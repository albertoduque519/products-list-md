import Search from '../../../assets/search.svg?react'
import Heart from '../../../assets/heart.svg?react'
import ArrowRight from '../../../assets/arrowRight.svg?react'
import Info from '../../../assets/info.svg?react'
import Flag from '../../../assets/flag.svg?react'
import Logo from '../../../assets/logo.svg?react'

const Icon = ({ type }: { type: string }) => {
    return (
        <>
            {type === 'search' && <Search />}
            {type === 'heart' && <Heart />}
            {type === 'arrowRight' && <ArrowRight />}
            {type === 'info' && <Info />}
            {type === 'flag' && <Flag />}
            {type === 'logo' && <Logo />}
        </>
    )
}

export default Icon