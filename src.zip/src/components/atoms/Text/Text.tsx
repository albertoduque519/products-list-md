import './style.css'

interface TextProps {
    text: string
}
const Text = ({ text }: TextProps) => <p>{text}</p>

export default Text