import './style.css'

const Separator = () => <hr />

export default Separator