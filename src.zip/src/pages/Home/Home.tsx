import DefaultLayout from "../../components/templates/DefaultLayout"
import CardsSection from "../../components/organisms/CardsSection/CardsSection.tsx"
import { useEffect, useState } from "react"

import './style.css'

const Home = () => {
  const [products, setProducts] = useState([
    { alt:'tv', image:'/assets/tv.jpg', name:'Tv de 43', description:'Es un tv para toda la familia', stock:'5', price:'30000' },
    { alt:'tv', image:'/assets/tv.jpg', name:'Tv de 43', description:'Es un tv para toda la familia', stock:'5', price:'30000' },
    { alt:'tv', image:'/assets/tv.jpg', name:'Tv de 43', description:'Es un tv para toda la familia', stock:'5', price:'30000' },
    { alt:'tv', image:'/assets/tv.jpg', name:'Tv de 43', description:'Es un tv para toda la familia', stock:'5', price:'30000' }
  ])

  return (
    <>
      <DefaultLayout>
        <CardsSection items={products} title="Últimos productos" subtitle="Novedades primavera 2024" />
        <CardsSection items={[...products].reverse()} highlighted title="Destacados" subtitle="Best sellers y ofertas" />
      </DefaultLayout>
    </>
  )
}

export default Home